import { MarketingPageShell } from "@/components/marketing/page-shell";

export default function AboutPage() {
  return (
    <MarketingPageShell
      title="About OrangeBoost"
      subtitle="Premium SMM panel built for creators, brands, and agencies."
    >
      <div className="space-y-4 text-sm text-muted">
        <p>
          OrangeBoost SMM is a modern Social Media Marketing (SMM) platform that lets you order
          growth services (followers, likes, views, comments and more) from a single dashboard.
        </p>
        <p>
          This project includes: wallet funding, order placement + tracking, support tickets, reseller
          API (MVP), and an admin panel for managing services and orders.
        </p>
      </div>
    </MarketingPageShell>
  );
}

