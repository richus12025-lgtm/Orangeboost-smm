import Link from "next/link";
import { MarketingNavbar } from "@/components/marketing/navbar";
import { MarketingFooter } from "@/components/marketing/footer";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default async function ServicesPage() {
  let services: any[] = [];
  try {
    if (process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY) {
      const supabase = await createSupabaseServerClient();
      const { data } = await supabase
        .from("services")
        .select("id,platform,name,price_per_1000,min_qty,max_qty,description,is_active")
        .eq("is_active", true)
        .order("platform");
      services = data ?? [];
    }
  } catch {
    services = [];
  }

  return (
    <div className="min-h-full">
      <MarketingNavbar />
      <main className="mx-auto max-w-6xl px-4 py-14">
        <div className="flex flex-col items-start justify-between gap-4 md:flex-row md:items-end">
          <div>
            <h1 className="text-3xl font-semibold tracking-tight">All Services</h1>
            <p className="mt-2 text-sm text-muted">
              Transparent pricing. Real-time order tracking. Premium delivery.
            </p>
          </div>
          <Link href="/signup">
            <Button>Get Started</Button>
          </Link>
        </div>

        <div className="mt-8 grid gap-4 md:grid-cols-2">
          {services.map((s) => (
            <Card key={s.id}>
              <div className="flex items-start justify-between gap-4">
                <div>
                  <div className="text-xs text-muted-2">{s.platform}</div>
                  <div className="text-lg font-semibold tracking-tight">{s.name}</div>
                  <div className="mt-2 text-sm text-muted">{s.description}</div>
                </div>
                <div className="text-right">
                  <div className="text-xs text-muted-2">Price</div>
                  <div className="text-lg font-semibold">${Number(s.price_per_1000).toFixed(2)}</div>
                  <div className="text-xs text-muted-2">per 1,000</div>
                </div>
              </div>
              <div className="mt-5 flex items-center justify-between rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm">
                <span className="text-muted">Min {s.min_qty} • Max {s.max_qty}</span>
                <Link href="/signup" className="text-primary hover:underline">
                  Order →
                </Link>
              </div>
            </Card>
          ))}
          {services.length === 0 && (
            <Card>
              <div className="text-sm text-muted">
                Services will appear here once you add them in Supabase (Admin → Services).
              </div>
            </Card>
          )}
        </div>
      </main>
      <MarketingFooter />
    </div>
  );
}
