import { MarketingPageShell } from "@/components/marketing/page-shell";

export default function ApiDocsPage() {
  return (
    <MarketingPageShell
      title="API Docs (MVP)"
      subtitle="Reseller-ready endpoints for service list, balance, and order creation."
    >
      <div className="space-y-4 text-sm text-muted">
        <p>
          In this MVP, API support is implemented as server routes protected by an API key stored per
          user. You can extend this into a full public documentation site.
        </p>
        <div className="space-y-2 rounded-3xl border border-white/10 bg-white/5 p-4">
          <div className="text-xs text-muted-2">Example endpoints</div>
          <pre className="overflow-auto text-xs text-foreground/90">
{`GET    /api/v1/services
GET    /api/v1/balance
POST   /api/v1/orders`}
          </pre>
        </div>
        <p className="text-xs text-muted-2">
          You can expand this page with full parameters, samples, and SDKs.
        </p>
      </div>
    </MarketingPageShell>
  );
}

