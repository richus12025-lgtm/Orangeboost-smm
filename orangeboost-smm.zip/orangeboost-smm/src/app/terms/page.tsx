import { MarketingPageShell } from "@/components/marketing/page-shell";

export default function TermsPage() {
  return (
    <MarketingPageShell title="Terms of Service" subtitle="Basic starter terms (replace with your legal copy).">
      <div className="space-y-4 text-sm text-muted">
        <p>
          By using OrangeBoost SMM, you agree to comply with applicable laws and the terms of the
          social platforms you use.
        </p>
        <p>
          Some services may be non-refundable once delivery has started. Contact support if you have
          an issue with an order.
        </p>
        <p className="text-xs text-muted-2">
          This is placeholder content and not legal advice.
        </p>
      </div>
    </MarketingPageShell>
  );
}

