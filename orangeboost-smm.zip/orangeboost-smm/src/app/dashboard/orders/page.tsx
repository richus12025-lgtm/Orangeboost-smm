import Link from "next/link";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default async function OrdersPage() {
  const supabase = await createSupabaseServerClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { data: orders } = await supabase
    .from("orders")
    .select(
      "id,created_at,status,quantity,progress,eta_hours,target_url,services(name,platform)"
    )
    .eq("user_id", user?.id ?? "")
    .order("created_at", { ascending: false })
    .limit(100);

  return (
    <div>
      <div className="flex items-end justify-between gap-4">
        <div>
          <div className="text-2xl font-semibold tracking-tight">Orders</div>
          <div className="mt-1 text-sm text-muted">
            Track status, progress, and estimated completion.
          </div>
        </div>
        <Link href="/dashboard/new-order">
          <Button>New Order</Button>
        </Link>
      </div>

      <div className="mt-6 space-y-4">
        {(orders ?? []).map((o: any) => {
          const delivered = Math.min(Number(o.progress ?? 0), Number(o.quantity ?? 0));
          const pct =
            o.quantity && o.quantity > 0 ? (delivered / Number(o.quantity)) * 100 : 0;
          return (
            <Card key={o.id}>
              <div className="flex flex-col justify-between gap-4 md:flex-row md:items-start">
                <div>
                  <div className="text-xs text-muted-2">
                    {new Date(o.created_at).toLocaleString()} • Order #{String(o.id).slice(0, 8)}
                  </div>
                  <div className="mt-1 text-lg font-semibold tracking-tight">
                    {o.services?.platform} • {o.services?.name}
                  </div>
                  <div className="mt-2 text-sm text-muted break-all">{o.target_url}</div>
                </div>
                <div className="text-right">
                  <div className="text-xs text-muted-2">Status</div>
                  <div className="text-sm font-semibold">{o.status}</div>
                  <div className="mt-2 text-xs text-muted-2">
                    ETA: {o.eta_hours ? `${o.eta_hours}h` : "—"}
                  </div>
                </div>
              </div>

              <div className="mt-5">
                <div className="flex items-center justify-between text-xs text-muted-2">
                  <span>
                    {delivered}/{o.quantity} Delivered
                  </span>
                  <span>{pct.toFixed(0)}%</span>
                </div>
                <div className="mt-2 h-3 w-full overflow-hidden rounded-full bg-white/10">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-primary to-primary-2 transition-all"
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </div>
            </Card>
          );
        })}
        {(orders ?? []).length === 0 && (
          <Card>
            <div className="text-sm text-muted">
              No orders yet. Place your first order from{" "}
              <Link className="text-primary hover:underline" href="/dashboard/new-order">
                New Order
              </Link>
              .
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
