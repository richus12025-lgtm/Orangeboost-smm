import Link from "next/link";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { Card } from "@/components/ui/card";
import { CreateTicketForm } from "@/components/tickets/create-ticket-form";

export default async function TicketsPage() {
  const supabase = await createSupabaseServerClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { data: tickets } = await supabase
    .from("tickets")
    .select("id,created_at,subject,status,category,priority")
    .eq("user_id", user?.id ?? "")
    .order("created_at", { ascending: false })
    .limit(50);

  return (
    <div className="grid gap-4 md:grid-cols-3">
      <Card>
        <div className="text-sm font-semibold">Create Ticket</div>
        <div className="mt-1 text-xs text-muted-2">Support replies appear in the thread.</div>
        <div className="mt-5">
          <CreateTicketForm />
        </div>
      </Card>

      <Card className="md:col-span-2">
        <div className="text-sm font-semibold">Your Tickets</div>
        <div className="mt-4 overflow-hidden rounded-2xl border border-white/10">
          <table className="w-full text-left text-sm">
            <thead className="bg-white/5 text-xs text-muted-2">
              <tr>
                <th className="px-4 py-3">Date</th>
                <th className="px-4 py-3">Subject</th>
                <th className="px-4 py-3">Category</th>
                <th className="px-4 py-3">Priority</th>
                <th className="px-4 py-3">Status</th>
              </tr>
            </thead>
            <tbody>
              {(tickets ?? []).map((t: any) => (
                <tr key={t.id} className="border-t border-white/10">
                  <td className="px-4 py-3 text-muted">{new Date(t.created_at).toLocaleString()}</td>
                  <td className="px-4 py-3">
                    <Link className="text-primary hover:underline" href={`/dashboard/tickets/${t.id}`}>
                      {t.subject}
                    </Link>
                  </td>
                  <td className="px-4 py-3 text-muted">{t.category}</td>
                  <td className="px-4 py-3 text-muted">{t.priority}</td>
                  <td className="px-4 py-3 text-muted">{t.status}</td>
                </tr>
              ))}
              {(tickets ?? []).length === 0 && (
                <tr>
                  <td className="px-4 py-6 text-muted" colSpan={5}>
                    No tickets yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
