import Link from "next/link";
import { notFound } from "next/navigation";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { Card } from "@/components/ui/card";
import { TicketReplyBox } from "@/components/tickets/ticket-thread";

export default async function TicketThreadPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const supabase = await createSupabaseServerClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { data: ticket } = await supabase
    .from("tickets")
    .select("id,subject,status,created_at,user_id")
    .eq("id", id)
    .maybeSingle();

  if (!ticket || ticket.user_id !== user?.id) return notFound();

  const { data: messages } = await supabase
    .from("ticket_messages")
    .select("id,created_at,sender,message")
    .eq("ticket_id", id)
    .order("created_at", { ascending: true });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <div className="text-2xl font-semibold tracking-tight">{ticket.subject}</div>
          <div className="mt-1 text-sm text-muted">
            Status: <span className="text-foreground">{ticket.status}</span>
          </div>
        </div>
        <Link className="text-sm text-primary hover:underline" href="/dashboard/tickets">
          Back to tickets
        </Link>
      </div>

      <Card>
        <div className="space-y-3">
          {(messages ?? []).map((m: any) => (
            <div
              key={m.id}
              className={
                m.sender === "admin"
                  ? "rounded-3xl border border-white/10 bg-white/5 p-4"
                  : "rounded-3xl border border-primary/30 bg-primary/10 p-4"
              }
            >
              <div className="flex items-center justify-between text-xs text-muted-2">
                <span>{m.sender === "admin" ? "Support" : "You"}</span>
                <span>{new Date(m.created_at).toLocaleString()}</span>
              </div>
              <div className="mt-2 whitespace-pre-wrap text-sm">{m.message}</div>
            </div>
          ))}
          {(messages ?? []).length === 0 && <div className="text-sm text-muted">No messages yet.</div>}
        </div>

        <TicketReplyBox ticketId={id} />
      </Card>
    </div>
  );
}
