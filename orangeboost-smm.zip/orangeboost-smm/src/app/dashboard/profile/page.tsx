import { createSupabaseServerClient } from "@/lib/supabase/server";
import { Card } from "@/components/ui/card";
import { ProfileForm } from "@/components/profile/profile-form";
import { ApiKeyCard } from "@/components/profile/api-key-card";

export default async function ProfilePage() {
  const supabase = await createSupabaseServerClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { data: profile } = await supabase
    .from("profiles")
    .select("full_name,username,phone,country")
    .eq("id", user?.id ?? "")
    .maybeSingle();

  const { data: apiKey } = await supabase
    .from("api_keys")
    .select("key")
    .eq("user_id", user?.id ?? "")
    .eq("is_active", true)
    .maybeSingle();

  return (
    <div className="grid gap-4 md:grid-cols-3">
      <Card>
        <div className="text-sm font-semibold">Account</div>
        <div className="mt-4 space-y-2 text-sm">
          <div>
            <div className="text-xs text-muted-2">Email</div>
            <div className="text-muted">{user?.email}</div>
          </div>
          <div>
            <div className="text-xs text-muted-2">User ID</div>
            <div className="text-muted break-all">{user?.id}</div>
          </div>
        </div>
        <div className="mt-6 text-xs text-muted-2">
          2FA and login activity can be added via Supabase Auth settings.
        </div>
      </Card>

      <Card className="md:col-span-2">
        <div className="text-sm font-semibold">Profile</div>
        <div className="mt-1 text-xs text-muted-2">Update your profile information.</div>
        <div className="mt-5">
          <ProfileForm initial={profile ?? {}} />
        </div>
      </Card>

      <Card className="md:col-span-3">
        <div className="text-sm font-semibold">API Access (Resellers)</div>
        <div className="mt-1 text-xs text-muted-2">
          Generate an API key to use the reseller endpoints.
        </div>
        <div className="mt-5">
          <ApiKeyCard initialKey={(apiKey as any)?.key ?? null} />
        </div>
      </Card>
    </div>
  );
}
