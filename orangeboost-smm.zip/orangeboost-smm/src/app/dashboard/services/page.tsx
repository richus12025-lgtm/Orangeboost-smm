import Link from "next/link";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default async function DashboardServicesPage() {
  const supabase = await createSupabaseServerClient();
  const { data } = await supabase
    .from("services")
    .select("id,platform,name,price_per_1000,min_qty,max_qty,speed,description,is_active")
    .eq("is_active", true)
    .order("platform");

  const services = data ?? [];

  return (
    <div>
      <div className="flex items-end justify-between gap-4">
        <div>
          <div className="text-2xl font-semibold tracking-tight">Services</div>
          <div className="mt-1 text-sm text-muted">
            Browse and place an order in seconds.
          </div>
        </div>
        <Link href="/dashboard/new-order">
          <Button>New Order</Button>
        </Link>
      </div>

      <div className="mt-6 grid gap-4 md:grid-cols-2">
        {services.map((s: any) => (
          <Card key={s.id}>
            <div className="flex items-start justify-between gap-4">
              <div>
                <div className="text-xs text-muted-2">{s.platform}</div>
                <div className="text-lg font-semibold tracking-tight">{s.name}</div>
                <div className="mt-2 text-sm text-muted">{s.description}</div>
              </div>
              <div className="text-right">
                <div className="text-xs text-muted-2">From</div>
                <div className="text-lg font-semibold">${Number(s.price_per_1000).toFixed(2)}</div>
                <div className="text-xs text-muted-2">per 1,000</div>
              </div>
            </div>
            <div className="mt-5 grid grid-cols-3 gap-3 text-sm">
              <div className="rounded-2xl border border-white/10 bg-white/5 p-3">
                <div className="text-xs text-muted-2">Min</div>
                <div className="font-semibold">{s.min_qty}</div>
              </div>
              <div className="rounded-2xl border border-white/10 bg-white/5 p-3">
                <div className="text-xs text-muted-2">Max</div>
                <div className="font-semibold">{s.max_qty}</div>
              </div>
              <div className="rounded-2xl border border-white/10 bg-white/5 p-3">
                <div className="text-xs text-muted-2">Speed</div>
                <div className="font-semibold">{s.speed ?? "Fast"}</div>
              </div>
            </div>
            <div className="mt-5">
              <Link href={`/dashboard/new-order?service=${s.id}`}>
                <Button className="w-full" variant="secondary">
                  Order Now
                </Button>
              </Link>
            </div>
          </Card>
        ))}
        {services.length === 0 && (
          <Card>
            <div className="text-sm text-muted">
              No services yet. As an admin, go to <Link className="text-primary hover:underline" href="/admin/services">Admin → Services</Link> to add your first service.
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
