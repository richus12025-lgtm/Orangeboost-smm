import { redirect } from "next/navigation";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { AppSidebar } from "@/components/app/sidebar";
import { AppTopbar } from "@/components/app/topbar";

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  if (!process.env.NEXT_PUBLIC_SUPABASE_URL || !process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY) {
    // App can render UI, but dashboard requires auth to be meaningful.
    redirect("/login");
  }

  const supabase = await createSupabaseServerClient();
  const { data } = await supabase.auth.getUser();
  const user = data.user;

  if (!user) redirect("/login");

  const { data: profile } = await supabase
    .from("profiles")
    .select("full_name,is_admin")
    .eq("id", user.id)
    .maybeSingle();

  const { data: wallet } = await supabase
    .from("wallets")
    .select("balance")
    .eq("user_id", user.id)
    .maybeSingle();

  return (
    <div className="min-h-[calc(100vh-0px)] md:flex">
      <AppSidebar isAdmin={Boolean(profile?.is_admin)} />
      <main className="flex-1 p-4 md:p-8">
        <div className="glass rounded-[32px] p-5 md:p-7">
          <AppTopbar fullName={profile?.full_name} balance={wallet?.balance ?? 0} />
        </div>
        <div className="mt-6">{children}</div>
      </main>
    </div>
  );
}
