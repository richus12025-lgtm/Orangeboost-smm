import { MarketingPageShell } from "@/components/marketing/page-shell";

export default function ContactPage() {
  return (
    <MarketingPageShell
      title="Contact"
      subtitle="Reach out for support, partnerships, or reseller inquiries."
    >
      <div className="space-y-3 text-sm text-muted">
        <p>
          Email: <span className="text-foreground">support@orangeboost.example</span>
        </p>
        <p>
          Telegram: <span className="text-foreground">@orangeboost</span>
        </p>
        <p className="text-xs text-muted-2">
          Replace these placeholders with your real contact details.
        </p>
      </div>
    </MarketingPageShell>
  );
}

