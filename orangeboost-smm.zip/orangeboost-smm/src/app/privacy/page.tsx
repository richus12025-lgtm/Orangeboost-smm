import { MarketingPageShell } from "@/components/marketing/page-shell";

export default function PrivacyPage() {
  return (
    <MarketingPageShell title="Privacy Policy" subtitle="Basic starter privacy policy (replace with your legal copy).">
      <div className="space-y-4 text-sm text-muted">
        <p>
          We collect account information (email, username) and usage data required to operate the
          service, such as orders, wallet transactions, and support messages.
        </p>
        <p>
          Payments are processed by third-party gateways (e.g., Paystack, Flutterwave). We do not
          store full card details on our servers.
        </p>
        <p className="text-xs text-muted-2">
          This is placeholder content and not legal advice.
        </p>
      </div>
    </MarketingPageShell>
  );
}

