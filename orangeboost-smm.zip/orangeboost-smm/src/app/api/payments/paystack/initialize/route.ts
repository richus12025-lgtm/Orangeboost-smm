import { NextRequest, NextResponse } from "next/server";
import { createServerClient } from "@supabase/ssr";

function randomRef() {
  return `ob_ps_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
}

export async function POST(req: NextRequest) {
  try {
    const { amount } = await req.json();
    const numericAmount = Number(amount);
    if (!numericAmount || numericAmount <= 0) {
      return NextResponse.json({ error: "Invalid amount" }, { status: 400 });
    }
    if (!process.env.PAYSTACK_SECRET_KEY) {
      return NextResponse.json(
        { error: "PAYSTACK_SECRET_KEY is not set" },
        { status: 500 }
      );
    }

    const supabase = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          getAll() {
            return req.cookies.getAll();
          },
          setAll() {},
        },
      }
    );
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user?.email) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const reference = randomRef();

    // Store an initiated transaction (credit only after verification/webhook).
    await supabase.from("wallet_transactions").insert({
      user_id: user.id,
      type: "deposit",
      amount: numericAmount,
      method: "paystack",
      status: "initiated",
      reference,
    });

    const callback_url = `${process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000"}/dashboard/wallet?ref=${reference}`;

    const paystackRes = await fetch("https://api.paystack.co/transaction/initialize", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        email: user.email,
        amount: Math.round(numericAmount * 100), // smallest currency unit
        reference,
        callback_url,
        metadata: { user_id: user.id, source: "orangeboost" },
      }),
    });

    const paystackJson = await paystackRes.json();
    if (!paystackRes.ok || !paystackJson?.status) {
      return NextResponse.json(
        { error: paystackJson?.message ?? "Paystack initialization failed" },
        { status: 400 }
      );
    }

    return NextResponse.json({
      authorization_url: paystackJson.data.authorization_url,
      reference,
    });
  } catch (e: any) {
    return NextResponse.json(
      { error: e?.message ?? "Server error" },
      { status: 500 }
    );
  }
}
