import { NextRequest, NextResponse } from "next/server";
import { createServerClient } from "@supabase/ssr";

function randomRef() {
  return `ob_fw_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
}

export async function POST(req: NextRequest) {
  try {
    const { amount } = await req.json();
    const numericAmount = Number(amount);
    if (!numericAmount || numericAmount <= 0) {
      return NextResponse.json({ error: "Invalid amount" }, { status: 400 });
    }
    if (!process.env.FLUTTERWAVE_SECRET_KEY) {
      return NextResponse.json(
        { error: "FLUTTERWAVE_SECRET_KEY is not set" },
        { status: 500 }
      );
    }

    const supabase = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          getAll() {
            return req.cookies.getAll();
          },
          setAll() {},
        },
      }
    );
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user?.email) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const reference = randomRef();
    await supabase.from("wallet_transactions").insert({
      user_id: user.id,
      type: "deposit",
      amount: numericAmount,
      method: "flutterwave",
      status: "initiated",
      reference,
    });

    const redirect_url = `${process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000"}/dashboard/wallet?ref=${reference}`;

    const fwRes = await fetch("https://api.flutterwave.com/v3/payments", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.FLUTTERWAVE_SECRET_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        tx_ref: reference,
        amount: numericAmount,
        currency: process.env.FLUTTERWAVE_CURRENCY ?? "NGN",
        redirect_url,
        customer: {
          email: user.email,
        },
        customizations: {
          title: "OrangeBoost SMM",
          description: "Wallet deposit",
        },
        meta: { user_id: user.id },
      }),
    });

    const fwJson = await fwRes.json();
    const link = fwJson?.data?.link;
    if (!fwRes.ok || !link) {
      return NextResponse.json(
        { error: fwJson?.message ?? "Flutterwave initialization failed" },
        { status: 400 }
      );
    }

    return NextResponse.json({
      authorization_url: link,
      reference,
    });
  } catch (e: any) {
    return NextResponse.json(
      { error: e?.message ?? "Server error" },
      { status: 500 }
    );
  }
}
