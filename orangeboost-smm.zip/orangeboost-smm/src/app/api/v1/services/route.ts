import { NextRequest, NextResponse } from "next/server";
import { requireApiUser } from "@/lib/api/api-key";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";

export async function GET(req: NextRequest) {
  const auth = await requireApiUser(req);
  if ("error" in auth) return NextResponse.json({ error: auth.error }, { status: 401 });

  const admin = createSupabaseAdminClient();
  const { data } = await admin
    .from("services")
    .select("id,platform,name,price_per_1000,min_qty,max_qty,speed,description")
    .eq("is_active", true)
    .order("platform");

  return NextResponse.json({ services: data ?? [] });
}

