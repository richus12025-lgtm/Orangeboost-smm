import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { requireApiUser } from "@/lib/api/api-key";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";

const BodySchema = z.object({
  service_id: z.string().min(1),
  target_url: z.string().min(5),
  quantity: z.number().int().positive(),
  notes: z.any().optional(),
});

export async function POST(req: NextRequest) {
  const auth = await requireApiUser(req);
  if ("error" in auth) return NextResponse.json({ error: auth.error }, { status: 401 });

  const json = await req.json().catch(() => null);
  const parsed = BodySchema.safeParse(json);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid body", details: parsed.error.flatten() }, { status: 400 });
  }

  const admin = createSupabaseAdminClient();
  const { data, error } = await admin
    .from("orders")
    .insert({
      user_id: auth.userId,
      service_id: parsed.data.service_id,
      target_url: parsed.data.target_url,
      quantity: parsed.data.quantity,
      notes: parsed.data.notes ?? null,
      status: "pending",
      progress: 0,
    })
    .select("id,status")
    .single();

  if (error) return NextResponse.json({ error: error.message }, { status: 400 });
  return NextResponse.json({ order: data });
}

