import { NextRequest, NextResponse } from "next/server";
import { requireApiUser } from "@/lib/api/api-key";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";

export async function GET(req: NextRequest) {
  const auth = await requireApiUser(req);
  if ("error" in auth) return NextResponse.json({ error: auth.error }, { status: 401 });

  const admin = createSupabaseAdminClient();
  const { data } = await admin
    .from("wallets")
    .select("balance")
    .eq("user_id", auth.userId)
    .maybeSingle();

  return NextResponse.json({ balance: Number(data?.balance ?? 0) });
}

