import { NextRequest, NextResponse } from "next/server";
import crypto from "crypto";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";

export async function POST(req: NextRequest) {
  const secret = process.env.PAYSTACK_SECRET_KEY;
  if (!secret) return NextResponse.json({ error: "Missing PAYSTACK_SECRET_KEY" }, { status: 500 });

  const rawBody = await req.text();
  const signature = req.headers.get("x-paystack-signature") ?? "";
  const expected = crypto.createHmac("sha512", secret).update(rawBody).digest("hex");

  if (signature !== expected) {
    return NextResponse.json({ error: "Invalid signature" }, { status: 401 });
  }

  const event = JSON.parse(rawBody);
  const eventType = event?.event;
  const data = event?.data;

  if (eventType !== "charge.success") {
    return NextResponse.json({ ok: true });
  }

  const reference = data?.reference;
  if (!reference) return NextResponse.json({ error: "Missing reference" }, { status: 400 });

  const admin = createSupabaseAdminClient();
  const { data: tx } = await admin
    .from("wallet_transactions")
    .select("id,user_id,amount,status")
    .eq("reference", reference)
    .maybeSingle();

  if (!tx) return NextResponse.json({ ok: true }); // ignore unknown refs
  if (tx.status === "success") return NextResponse.json({ ok: true }); // idempotent

  await admin.from("wallet_transactions").update({ status: "success" }).eq("id", tx.id);
  await admin.rpc("wallet_credit", { p_user_id: tx.user_id, p_amount: tx.amount });

  return NextResponse.json({ ok: true });
}

