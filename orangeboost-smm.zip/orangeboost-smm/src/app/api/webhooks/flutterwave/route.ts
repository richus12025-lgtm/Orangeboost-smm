import { NextRequest, NextResponse } from "next/server";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";

export async function POST(req: NextRequest) {
  const expectedHash = process.env.FLUTTERWAVE_WEBHOOK_HASH;
  if (!expectedHash) {
    return NextResponse.json(
      { error: "Missing FLUTTERWAVE_WEBHOOK_HASH" },
      { status: 500 }
    );
  }

  const hash = req.headers.get("verif-hash") ?? "";
  if (hash !== expectedHash) {
    return NextResponse.json({ error: "Invalid signature" }, { status: 401 });
  }

  const body = await req.json();
  const eventType = body?.event;
  const data = body?.data;

  // Typical successful flow:
  // event: "charge.completed", data.status: "successful", data.tx_ref
  if (eventType !== "charge.completed" || data?.status !== "successful") {
    return NextResponse.json({ ok: true });
  }

  const reference = data?.tx_ref;
  if (!reference) return NextResponse.json({ error: "Missing tx_ref" }, { status: 400 });

  const admin = createSupabaseAdminClient();
  const { data: tx } = await admin
    .from("wallet_transactions")
    .select("id,user_id,amount,status")
    .eq("reference", reference)
    .maybeSingle();

  if (!tx) return NextResponse.json({ ok: true });
  if (tx.status === "success") return NextResponse.json({ ok: true });

  await admin.from("wallet_transactions").update({ status: "success" }).eq("id", tx.id);
  await admin.rpc("wallet_credit", { p_user_id: tx.user_id, p_amount: tx.amount });

  return NextResponse.json({ ok: true });
}

