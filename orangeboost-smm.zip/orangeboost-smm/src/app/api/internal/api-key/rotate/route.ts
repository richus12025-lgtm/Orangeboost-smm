import { NextRequest, NextResponse } from "next/server";
import crypto from "crypto";
import { createServerClient } from "@supabase/ssr";

function newKey() {
  return `ob_${crypto.randomBytes(24).toString("hex")}`;
}

export async function POST(req: NextRequest) {
  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return req.cookies.getAll();
        },
        setAll() {},
      },
    }
  );
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  // Deactivate old keys (keep history).
  await supabase.from("api_keys").update({ is_active: false }).eq("user_id", user.id);

  const key = newKey();
  const { error } = await supabase.from("api_keys").insert({
    user_id: user.id,
    key,
    is_active: true,
  });
  if (error) return NextResponse.json({ error: error.message }, { status: 400 });

  return NextResponse.json({ key });
}
