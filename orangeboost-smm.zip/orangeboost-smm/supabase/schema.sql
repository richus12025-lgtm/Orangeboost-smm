-- OrangeBoost SMM (Supabase/Postgres) starter schema
-- Run in Supabase SQL editor.

create extension if not exists "pgcrypto";

-- 1) Profiles
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  full_name text,
  username text unique,
  phone text,
  country text,
  is_admin boolean not null default false
);

-- 2) Wallet
create table if not exists public.wallets (
  user_id uuid primary key references auth.users(id) on delete cascade,
  updated_at timestamptz not null default now(),
  balance numeric not null default 0
);

create table if not exists public.wallet_transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  type text not null, -- deposit | withdraw | transfer
  amount numeric not null,
  method text, -- paystack | flutterwave | crypto | bank
  status text not null default 'initiated', -- initiated | success | failed
  reference text unique
);

-- 3) Services + Orders
create table if not exists public.services (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  platform text not null,
  name text not null,
  price_per_1000 numeric not null,
  min_qty int not null default 1,
  max_qty int not null default 1000000,
  speed text,
  description text,
  is_active boolean not null default true
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  user_id uuid not null references auth.users(id) on delete cascade,
  service_id uuid not null references public.services(id),
  target_url text not null,
  quantity int not null,
  notes jsonb,
  status text not null default 'pending', -- pending | processing | completed | cancelled
  progress int not null default 0,
  eta_hours int
);

-- 4) Support tickets
create table if not exists public.tickets (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  user_id uuid not null references auth.users(id) on delete cascade,
  subject text not null,
  category text not null,
  priority text not null default 'normal',
  status text not null default 'open'
);

create table if not exists public.ticket_messages (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  ticket_id uuid not null references public.tickets(id) on delete cascade,
  sender text not null, -- user | admin
  message text not null
);

-- 5) API keys (resellers)
create table if not exists public.api_keys (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  user_id uuid not null references auth.users(id) on delete cascade,
  key text not null unique,
  is_active boolean not null default true
);

-- ---------------------------------------------------------------------------
-- Triggers: auto-create profile + wallet for new users
-- ---------------------------------------------------------------------------
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
as $$
begin
  insert into public.profiles (id, full_name, username, phone, country)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name', ''),
    nullif(new.raw_user_meta_data->>'username', ''),
    nullif(new.raw_user_meta_data->>'phone', ''),
    nullif(new.raw_user_meta_data->>'country', '')
  )
  on conflict (id) do nothing;

  insert into public.wallets (user_id, balance)
  values (new.id, 0)
  on conflict (user_id) do nothing;

  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ---------------------------------------------------------------------------
-- Helper functions for wallet credits/debits (used by webhook handlers)
-- ---------------------------------------------------------------------------
create or replace function public.wallet_credit(p_user_id uuid, p_amount numeric)
returns void
language plpgsql
security definer
as $$
begin
  insert into public.wallets (user_id, balance)
  values (p_user_id, p_amount)
  on conflict (user_id) do update
    set balance = public.wallets.balance + excluded.balance,
        updated_at = now();
end;
$$;

-- ---------------------------------------------------------------------------
-- Row Level Security (RLS)
-- ---------------------------------------------------------------------------
alter table public.profiles enable row level security;
alter table public.wallets enable row level security;
alter table public.wallet_transactions enable row level security;
alter table public.services enable row level security;
alter table public.orders enable row level security;
alter table public.tickets enable row level security;
alter table public.ticket_messages enable row level security;
alter table public.api_keys enable row level security;

-- Admin check helper (inline)
-- exists(select 1 from public.profiles p where p.id = auth.uid() and p.is_admin)

-- profiles
create policy "profiles_select_own" on public.profiles
  for select using (auth.uid() = id);

create policy "profiles_update_own" on public.profiles
  for update using (auth.uid() = id) with check (auth.uid() = id);

create policy "profiles_admin_all" on public.profiles
  for all using (exists(select 1 from public.profiles p where p.id = auth.uid() and p.is_admin));

-- wallets
create policy "wallets_select_own" on public.wallets
  for select using (auth.uid() = user_id);

create policy "wallets_admin_all" on public.wallets
  for all using (exists(select 1 from public.profiles p where p.id = auth.uid() and p.is_admin));

-- wallet_transactions
create policy "wallet_tx_select_own" on public.wallet_transactions
  for select using (auth.uid() = user_id);

create policy "wallet_tx_insert_own" on public.wallet_transactions
  for insert with check (auth.uid() = user_id);

create policy "wallet_tx_admin_all" on public.wallet_transactions
  for all using (exists(select 1 from public.profiles p where p.id = auth.uid() and p.is_admin));

-- services
create policy "services_select_public_active" on public.services
  for select using (is_active = true);

create policy "services_admin_write" on public.services
  for insert with check (exists(select 1 from public.profiles p where p.id = auth.uid() and p.is_admin));

create policy "services_admin_update" on public.services
  for update using (exists(select 1 from public.profiles p where p.id = auth.uid() and p.is_admin))
  with check (exists(select 1 from public.profiles p where p.id = auth.uid() and p.is_admin));

-- orders
create policy "orders_select_own" on public.orders
  for select using (auth.uid() = user_id);

create policy "orders_insert_own" on public.orders
  for insert with check (auth.uid() = user_id);

create policy "orders_admin_all" on public.orders
  for all using (exists(select 1 from public.profiles p where p.id = auth.uid() and p.is_admin));

-- tickets
create policy "tickets_select_own" on public.tickets
  for select using (auth.uid() = user_id);

create policy "tickets_insert_own" on public.tickets
  for insert with check (auth.uid() = user_id);

create policy "tickets_admin_all" on public.tickets
  for all using (exists(select 1 from public.profiles p where p.id = auth.uid() and p.is_admin));

-- ticket_messages
create policy "ticket_messages_select_own" on public.ticket_messages
  for select using (
    exists(select 1 from public.tickets t where t.id = ticket_id and t.user_id = auth.uid())
  );

create policy "ticket_messages_insert_own" on public.ticket_messages
  for insert with check (
    exists(select 1 from public.tickets t where t.id = ticket_id and t.user_id = auth.uid())
  );

create policy "ticket_messages_admin_all" on public.ticket_messages
  for all using (exists(select 1 from public.profiles p where p.id = auth.uid() and p.is_admin));

-- api_keys
create policy "api_keys_select_own" on public.api_keys
  for select using (auth.uid() = user_id);

create policy "api_keys_write_own" on public.api_keys
  for insert with check (auth.uid() = user_id);

create policy "api_keys_update_own" on public.api_keys
  for update using (auth.uid() = user_id) with check (auth.uid() = user_id);

